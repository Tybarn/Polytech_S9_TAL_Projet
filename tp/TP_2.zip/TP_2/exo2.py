


inputFile = open("wsj_0010_sample.txt.se.xml",'r')
entities = []
categ
